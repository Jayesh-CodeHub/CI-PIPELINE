import paramiko
import openpyxl
import win32cred
import os
import sys
import json
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def microbot1():
    #########################################################################################################################
    sys.path.append(os.path.dirname(os.path.dirname(os.getcwd())))
    parent_directory = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    config_file_path = os.path.join(parent_directory, "conf", "config.json")
    #########################################################################################################################

    # Define the list of commands 
    commands = [
        "rows 0",
        "system health status show",
        "storage shelf show -connectivity",
        "storage disk show -broken",
        "system health alert show -instance",
        "network port show",
        "network interface show -status",
        "network interface show -status-oper down",
        "volume show -state !online",
        "snapmirror show -healthy false"
    ]

    def get_credentials():
        try:
            creds = win32cred.CredRead("Matalan", win32cred.CRED_TYPE_GENERIC, 0)
            username = creds['UserName']
            password = creds['CredentialBlob']
            return username, password.decode('utf-16')
        except Exception as e:
            print(f"Error retrieving credentials: {str(e)}")
            return None, None

    def ssh_connect(server_ip, username, password, log_file, report_file):
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(hostname=server_ip, username=username, password=password)
            connection_msg = f"{datetime.now()} - Connected to {server_ip}\n"
            log_file.write(connection_msg)
            print(connection_msg)

            for command in commands:
                command_msg = f"{datetime.now()} - Executing command on {server_ip}: {command}\n"
                log_file.write(command_msg)
                print(command_msg)
                
                stdin, stdout, stderr = ssh_client.exec_command(command)
                output = ''.join(stdout.readlines())
                write_to_report(report_file, server_ip, command, output)
                print(output)

            ssh_client.close()
        except Exception as e:
            error_msg = f"{datetime.now()} - Error connecting to {server_ip}: {str(e)}\n"
            log_file.write(error_msg)
            print(error_msg)
            return False

        return True

    def write_to_report(report_file, server_ip, command, output):
        highlight_mapping = {
            "ok": "#00FF00",
            "healthy": "#00FF00",
            "up": "#00FF00",
            "down": "#FF0000",
            "active": "green"
        }

        for keyword, color in highlight_mapping.items():
            output = output.replace(keyword, f"<span style='background-color: {color};'>{keyword}</span>")
        
        output = f"<pre>{output}</pre>"

        report_file.write("<tr>")
        report_file.write(f"<td>{server_ip}</td>")
        report_file.write(f"<td>{command}</td>")
        report_file.write(f"<td>{output}</td>")
        report_file.write("</tr>\n")

    def send_email(subject, body, attachment_path):
        try:
            with open(config_file_path) as f:
                config_data = json.load(f)
                email_config = config_data.get("email_config")

            if email_config:
                sender_email = email_config.get("sender_email")
                receiver_email = email_config.get("receiver_email")
                smtp_server = email_config.get("smtp_server")
                smtp_port = email_config.get("smtp_port")
                
                message = MIMEMultipart()
                message["From"] = sender_email
                message["To"] = receiver_email
                message["Subject"] = subject

                message.attach(MIMEText(body, "plain"))

                with open(attachment_path, "rb") as attachment:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(attachment.read())

                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename= {os.path.basename(attachment_path)}")
                message.attach(part)
                text = message.as_string()

                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls()
                    server.sendmail(sender_email, receiver_email, text)
                
                print(f"Email sent successfully to {receiver_email}")
        except Exception as e:
            print(f"Error sending email: {str(e)}")

    try:
        execution_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        excel_file = os.path.join(parent_directory, "input", "server_details.xlsx")
        wb = openpyxl.load_workbook(excel_file)
        sheet = wb.active
        username, password = get_credentials()
        connection_error = False

        log_file_path = os.path.join(parent_directory, "log", "log.txt")
        with open(log_file_path, "a") as log_file:
            report_file_path = os.path.join(parent_directory, "output", "report.html")
            with open(report_file_path, "w") as report_file:
                report_file.write(f"<html><head><title>NetApp Health-Check Report - {execution_time}</title>")
                report_file.write("<style>")
                report_file.write("table {border-collapse: collapse; width: 100%;}")
                report_file.write("th, td {padding: 15px; text-align: left;}")
                report_file.write("th {background-color: #4CAF50; color: white;}")
                report_file.write("</style>")
                report_file.write("</head><body>")
                report_file.write(f"<h1>Matalan NetApp Health-Check Report - {execution_time}</h1>")
                report_file.write("<table border='1' cellpadding='10'>")
                report_file.write("<tr><th>Server IP</th><th>Command</th><th>Output</th></tr>")

                for row in sheet.iter_rows(min_row=2, max_col=2, values_only=True):
                    server_ip, _ = row
                    connected = ssh_connect(server_ip, username, password, log_file, report_file)
                    if not connected:
                        connection_error = True
                report_file.write("</table></body></html>")
        
        if connection_error:
            send_email("Matalan NetApp Health-Check Report", "Error connecting to servers.", log_file_path)
        else:
            send_email("Matalan NetApp Health-Check Report", "Please find attached the report.", report_file_path)
    except Exception as e:
        print(f"Error: {str(e)}")

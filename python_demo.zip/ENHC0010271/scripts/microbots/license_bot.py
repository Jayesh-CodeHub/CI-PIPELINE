import datetime

def license_check():
    try:
        # Expiry date of the bot
        expiry_date = datetime.date(2025, 3, 20)
        
        # Get the current date
        current_date = datetime.date.today()

        # Calculate the remaining days
        remaining_days = (expiry_date - current_date).days

        # Check if the current date is before the expiry date
        if current_date <= expiry_date:
            return True, f'License is valid. {remaining_days} days remaining until expiration.'
        else:
            return False, f'License for this bot has expired {remaining_days} day ago.'
    except Exception as e:
        return False, f'Error validating license: {e}'


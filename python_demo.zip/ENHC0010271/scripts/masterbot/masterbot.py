import os
import sys
import logging

sys.path.append(os.path.dirname(os.path.dirname(os.getcwd())))
parent_directory = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
script_path = os.path.join(parent_directory, "scripts")
microbot_path = os.path.join(script_path,"microbots")
input_path = os.path.join(parent_directory, "input")
input_file_path = os.path.join(parent_directory, 'input', "server_details.xlsx")
config_File_Path = os.path.join(parent_directory, "conf","config.json")


from scripts.microbots.microbot1 import microbot1
from scripts.microbots.license_bot import license_check

def main():
    log_file_path = os.path.join(parent_directory, "log", "log.txt")
    license_status, license_message = license_check()
    with open(log_file_path, "a") as log_file:
        print(license_message)
        log_file.write(license_message + "\n")
        if license_status:
            microbot1()



        else:
            log_file.write("License expired or invalid")
            log_file.write(license_message)
            sys.exit(1)

if __name__ == "__main__":
    main()
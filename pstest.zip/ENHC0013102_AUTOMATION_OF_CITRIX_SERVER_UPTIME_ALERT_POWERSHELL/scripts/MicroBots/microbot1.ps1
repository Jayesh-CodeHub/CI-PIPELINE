param (

        [Parameter(Mandatory=$false)]
        [string]$ServersFilePath,
        
        [Parameter(Mandatory=$false)]
        [string]$ConfigFilePath,
         
        [Parameter(Mandatory=$false)]
        [string]$outputFolderPath,
        
        [Parameter(Mandatory=$false)]
        [string]$DomainName = "YOURDOMAIN"
    )

function Start-CitrixMonitoring {
    [CmdletBinding()]
    param (

        [Parameter(Mandatory=$false)]
        [string]$ServersFilePath,
        
        [Parameter(Mandatory=$false)]
        [string]$ConfigFilePath,
         
        [Parameter(Mandatory=$false)]
        [string]$outputFolderPath,
        
        [Parameter(Mandatory=$false)]
        [string]$DomainName = "YOURDOMAIN"
    )
    
    # Load configuration from JSON file
    try {
        if (Test-Path -Path $ConfigFilePath) {
            Write-Verbose "Loading configuration from $ConfigFilePath"
            $config = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
            
            # Read configuration values with fallbacks
            $UptimeThreshold = if ($config.UptimeThreshold) { $config.UptimeThreshold } else { 24 }
            $PingTimeoutMs = if ($config.PingTimeoutMs) { $config.PingTimeoutMs } else { 2000 }
            $CpuThreshold = if ($config.CpuThreshold) { $config.CpuThreshold } else { 80 }
            $MemoryThreshold = if ($config.MemoryThreshold) { $config.MemoryThreshold } else { 80 }
            $DomainName = if ($config.DomainName) { $config.DomainName } else { $DomainName }
            
            # Check if DriveCheckServers is in config
            if ($config.DriveCheckServers) {
                $DriveCheckServers = $config.DriveCheckServers
            } else {
                # Default if not in config
                $DriveCheckServers = @()
            }
            
            Write-Verbose "Loaded configuration: Uptime=$UptimeThreshold, CPU=$CpuThreshold%, Memory=$MemoryThreshold%, Domain=$DomainName"
        } else {
            Write-Warning "Configuration file not found at $ConfigFilePath. Using default values."
            $UptimeThreshold = 24
            $PingTimeoutMs = 2000
            $CpuThreshold = 80
            $MemoryThreshold = 80
            $DriveCheckServers = @()
        }
    } catch {
        Write-Error ("Failed to load configuration from ${ConfigFilePath}: " + $_.Exception.Message)
        Write-Warning "Using default configuration values."
        $UptimeThreshold = 24
        $PingTimeoutMs = 2000
        $CpuThreshold = 80
        $MemoryThreshold = 80
        $DriveCheckServers = @()
    }
    
    # Read servers from file
    try {
        if (Test-Path -Path $ServersFilePath) {
            Write-Verbose "Reading servers from $ServersFilePath"
            $Servers = Get-Content -Path $ServersFilePath | Where-Object { ![string]::IsNullOrWhiteSpace($_) }
            
            if ($Servers.Count -eq 0) {
                Write-Warning "No servers found in $ServersFilePath. Using default servers."
                $Servers = @("wvdap001", "wvdap002", "wvdap003")
            }
            
            Write-Verbose "Found $($Servers.Count) servers in file."
        } else {
            Write-Warning "Servers file not found at $ServersFilePath. Using default servers."
            $Servers = @("wvdap001", "wvdap002", "wvdap003")
        }
        
        # If DriveCheckServers is empty and not defined in config, use first two servers by default
        if ($DriveCheckServers.Count -eq 0) {
            if ($Servers.Count -ge 2) {
                $DriveCheckServers = $Servers[0..1]
            } else {
                $DriveCheckServers = $Servers
            }
            Write-Verbose "Using default DriveCheckServers: $($DriveCheckServers -join ', ')"
        }
    } catch {
        Write-Error ("Failed to read servers from ${ServersFilePath}: " + $_.Exception.Message)
        Write-Warning "Using default servers."
        $Servers = @("wvdap001", "wvdap002", "wvdap003")
        $DriveCheckServers = @("wvdap001", "wvdap002")
    }

    # Load the Citrix SnapIns first (required to run Citrix cmdlets)
    if (-not (Get-PSSnapin -Name "Citrix.XenApp.Commands" -ErrorAction SilentlyContinue)) {
        try {
            Add-PSSnapin -Name "Citrix*" -ErrorAction Stop
            Write-Verbose "Successfully loaded Citrix PowerShell snapins."
        } catch {
            Write-Error ("Failed to load Citrix PowerShell snapins. Make sure Citrix components are installed: " + $_.Exception.Message)
            return
        }
    }

    # Function to get Citrix information
    function Get-CitrixInfo {
        param (
            [string]$server
        )
        
        # Create result object with default values
        $result = [PSCustomObject]@{
            ServerName           = $server
            ConnectionStatus     = "Unknown"
            BrokerAgentVersion   = "Unknown"
            PrintServiceStatus   = "Unknown"
            RegistrationState    = "Unknown"
            ActiveSessions       = 0
            DisconnectedSessions = 0
            TotalSessions        = 0
            EDriveUsedGB         = "N/A"
            EDriveFreeGB         = "N/A"
            CPUUsage             = "N/A"
            MemoryUsage          = "N/A"
            ExceedsUptimeLimit   = $false
            ExceedsCPULimit      = $false
            ExceedsMemoryLimit   = $false
            LastBootTime         = "Unknown"
            UptimeHours          = "N/A"
            UptimeDays           = "N/A"  # Added uptime in days
            PingResponseTime     = "N/A"
            CheckDriveSpace      = ($DriveCheckServers -contains $server)
        }
        
        try {
            # Test connection before proceeding with improved timeout
            try {
                $ping = New-Object System.Net.NetworkInformation.Ping
                $pingReply = $ping.Send($server, $PingTimeoutMs)
                if ($pingReply.Status -eq "Success") {
                    $result.ConnectionStatus = "Online"
                    $result.PingResponseTime = "$($pingReply.RoundtripTime) ms"
                } else {
                    $result.ConnectionStatus = "Server Offline"
                    return $result
                }
            } catch {
                $result.ConnectionStatus = "Server Offline"
                return $result
            }
            
            # Try different machine name formats to ensure we find the proper Citrix machine
            # Format 1: Just server name
            $machineFormat1 = "$server"
            # Format 2: Domain\server
            $machineFormat2 = "$DomainName\$server"
            # Format 3: FQDN
            $machineFormat3 = "$server.$DomainName.local"
            # Array of formats to try
            $machineFormats = @($machineFormat1, $machineFormat2, $machineFormat3)
            
            $foundMachine = $false
            $machineName = $null
            
            # Try each format until we find a match
            foreach ($format in $machineFormats) {
                try {
                    $machine = Get-BrokerMachine -MachineName $format -ErrorAction SilentlyContinue
                    if ($machine) {
                        $machineName = $format
                        $foundMachine = $true
                        break
                    }
                } catch {
                    # Continue to next format
                }
            }
            
            if (-not $foundMachine) {
                # Try a wildcard search as last resort
                try {
                    $machines = Get-BrokerMachine -DNSName "*$server*" -ErrorAction Stop
                    if ($machines -and $machines.Count -gt 0) {
                        $machineName = $machines[0].MachineName
                        $foundMachine = $true
                    }
                } catch {
                    # Continue with other approaches
                }
            }
            
            # If we still haven't found the machine, try another approach with DNS name
            if (-not $foundMachine) {
                try {
                    $allMachines = Get-BrokerMachine -MaxRecordCount 1000 -ErrorAction Stop
                    $matchingMachine = $allMachines | Where-Object { 
                        $_.DNSName -like "*$server*" -or 
                        $_.HostedMachineName -like "*$server*" -or 
                        $_.MachineName -like "*$server*" 
                    } | Select-Object -First 1
                    
                    if ($matchingMachine) {
                        $machineName = $matchingMachine.MachineName
                        $foundMachine = $true
                    }
                } catch {
                    # Continue with other WMI-based checks
                }
            }
            
            # If machine still not found, continue with other WMI-based checks
            if (-not $foundMachine) {
                $result.RegistrationState = "Not Found in Citrix"
                
                # Continue with other WMI-based checks that don't require Citrix broker
            } else {
                # Get Connection Status and Registration State
                try {
                    $brokerMachine = Get-BrokerMachine -MachineName $machineName -ErrorAction Stop
                    if ($brokerMachine) {
                        $result.RegistrationState = $brokerMachine.RegistrationState
                        $result.ConnectionStatus = if ([string]::IsNullOrEmpty($brokerMachine.SessionState)) { 
                            "No Sessions" 
                        } else { 
                            $brokerMachine.SessionState 
                        }
                    }
                } catch {
                    # Error handling silently continued
                }
                
                # Get session information
                try {
                    # Get all sessions for this machine
                    $allSessions = Get-BrokerSession -MachineName $machineName -ErrorAction Stop
                    
                    # Count active and disconnected sessions
                    $activeSessions = $allSessions | Where-Object { $_.SessionState -eq "Active" }
                    $disconnectedSessions = $allSessions | Where-Object { $_.SessionState -eq "Disconnected" }
                    
                    $result.ActiveSessions = ($activeSessions | Measure-Object).Count
                    $result.DisconnectedSessions = ($disconnectedSessions | Measure-Object).Count
                    $result.TotalSessions = $result.ActiveSessions + $result.DisconnectedSessions
                } catch {
                    $result.ActiveSessions = "Error"
                    $result.DisconnectedSessions = "Error"
                    $result.TotalSessions = "Error"
                }
                
                # Get Broker Agent Version
                try {
                    if ($brokerMachine -and $brokerMachine.BrokerAgentVersion) {
                        $result.BrokerAgentVersion = $brokerMachine.BrokerAgentVersion
                    }
                } catch {
                    # Error handling silently continued
                }
            }
            
            # Get Print Service Status - WMI based, not Citrix specific
            try {
                $printService = Get-Service -Name "Spooler" -ComputerName $server -ErrorAction Stop
                if ($printService) {
                    $result.PrintServiceStatus = $printService.Status
                }
            } catch {
                $result.PrintServiceStatus = "Error"
            }
            
            # Get E: Drive Usage - Only for servers in the driveCheckServers list
            if ($DriveCheckServers -contains $server) {
                try {
                    $drive = Get-WmiObject -Class Win32_LogicalDisk -ComputerName $server -Filter "DeviceID='E:'" -ErrorAction Stop
                    if ($drive) {
                        $result.EDriveUsedGB = [math]::Round(($drive.Size - $drive.FreeSpace)/1GB, 2)
                        $result.EDriveFreeGB = [math]::Round($drive.FreeSpace/1GB, 2)
                    }
                } catch {
                    $result.EDriveUsedGB = "Error"
                    $result.EDriveFreeGB = "Error"
                }
            }
            
            # Get CPU Usage - WMI based, not Citrix specific
            try {
                $cpuInfo = Get-WmiObject -Class Win32_Processor -ComputerName $server -ErrorAction Stop | 
                           Measure-Object -Property LoadPercentage -Average
                $result.CPUUsage = [math]::Round($cpuInfo.Average, 2)
                
                # Check if CPU usage exceeds threshold
                if ($result.CPUUsage -ne "N/A" -and $result.CPUUsage -ne "Error") {
                    if ($result.CPUUsage -is [double] -or $result.CPUUsage -is [int]) {
                        $result.ExceedsCPULimit = $result.CPUUsage -gt $CpuThreshold
                    }
                }
            } catch {
                $result.CPUUsage = "Error"
            }
            
            # Get Memory Usage - WMI based, not Citrix specific
            try {
                $operatingSystem = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server -ErrorAction Stop
                if ($operatingSystem) {
                    $totalMemory = [math]::Round($operatingSystem.TotalVisibleMemorySize / 1MB, 2)
                    $freeMemory = [math]::Round($operatingSystem.FreePhysicalMemory / 1MB, 2)
                    $usedMemory = $totalMemory - $freeMemory
                    $memoryUsagePercent = [math]::Round(($usedMemory / $totalMemory) * 100, 2)
                    
                    $result.MemoryUsage = "$memoryUsagePercent% ($usedMemory/$totalMemory GB)"
                    
                    # Check if memory usage exceeds threshold
                    $result.ExceedsMemoryLimit = $memoryUsagePercent -gt $MemoryThreshold
                }
            } catch {
                $result.MemoryUsage = "Error"
            }
            
            # Get Server Uptime - WMI based, not Citrix specific
            try {
                $os = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server -ErrorAction Stop
                if ($os) {
                    $lastBootTime = $os.ConvertToDateTime($os.LastBootUpTime)
                    $result.LastBootTime = $lastBootTime.ToString("yyyy-MM-dd HH:mm:ss")
                    $uptime = (Get-Date) - $lastBootTime
                    
                    # Calculate uptime in hours and days
                    $uptimeHours = [math]::Round($uptime.TotalHours, 2)
                    $uptimeDays = [math]::Round($uptime.TotalDays, 2)
                    
                    # Format days as whole days and hours
                    $wholeDays = [math]::Floor($uptimeDays)
                    $remainingHours = [math]::Round(($uptimeDays - $wholeDays) * 24, 0)
                    $formattedUptime = "$wholeDays days, $remainingHours hours"
                    
                    $result.UptimeHours = $uptimeHours
                    $result.UptimeDays = $formattedUptime
                    
                    # Check if uptime exceeds threshold
                    $result.ExceedsUptimeLimit = $uptimeHours -gt $UptimeThreshold
                }
            } catch {
                $result.LastBootTime = "Error"
                $result.UptimeHours = "Error"
                $result.UptimeDays = "Error"
            }
            
            return $result
            
        } catch {
            Write-Error ("Error processing server ${server}: " + $_.Exception.Message)
            return [PSCustomObject]@{
                ServerName           = $server
                ConnectionStatus     = "Error"
                BrokerAgentVersion   = "Error"
                PrintServiceStatus   = "Error"
                RegistrationState    = "Error"
                ActiveSessions       = "Error"
                DisconnectedSessions = "Error"
                TotalSessions        = "Error"
                EDriveUsedGB         = "Error"
                EDriveFreeGB         = "Error"
                CPUUsage             = "Error"
                MemoryUsage          = "Error"
                ExceedsUptimeLimit   = $false
                ExceedsCPULimit      = $false
                ExceedsMemoryLimit   = $false
                LastBootTime         = "Error"
                UptimeHours          = "Error"
                UptimeDays           = "Error"
                PingResponseTime     = "Error"
                CheckDriveSpace      = ($DriveCheckServers -contains $server)
            }
        }
    }

    # Get total environment session counts
    try {
        $activeSessions = Get-BrokerSession -SessionState "Active" -ErrorAction Stop
        $disconnectedSessions = Get-BrokerSession -SessionState "Disconnected" -ErrorAction Stop
        $activeCount = ($activeSessions | Measure-Object).Count
        $disconnectedCount = ($disconnectedSessions | Measure-Object).Count
        
        # Get registered and unregistered desktops
        $registeredDesktops = Get-BrokerMachine -MaxRecordCount 20000 -Filter {RegistrationState -eq "Registered" -and PowerState -eq "On"} -ErrorAction Stop
        $unregisteredDesktops = Get-BrokerMachine -MaxRecordCount 20000 -Filter {RegistrationState -eq "Unregistered" -and PowerState -eq "On"} -ErrorAction Stop
        $regCount = ($registeredDesktops | Measure-Object).Count
        $unregCount = ($unregisteredDesktops | Measure-Object).Count
        
        Write-Verbose "Environment stats: Active=$activeCount, Disconnected=$disconnectedCount, Registered=$regCount, Unregistered=$unregCount"
    } catch {
        Write-Error ("Failed to retrieve environment statistics: " + $_.Exception.Message)
        $activeCount = "Error"
        $disconnectedCount = "Error"
        $regCount = "Error"
        $unregCount = "Error"
    }

    # Retrieve information for each server
    Write-Verbose "Processing $($Servers.Count) servers..."
    $results = @()
    foreach ($server in $Servers) {
        Write-Verbose "Processing server: $server"
        $serverInfo = Get-CitrixInfo -server $server
        $results += $serverInfo
    }

    # Split servers into those with drive space check and those without
    $serversWithDriveCheck = $results | Where-Object { $_.CheckDriveSpace -eq $true }
    $serversWithoutDriveCheck = $results | Where-Object { $_.CheckDriveSpace -eq $false }

    # Count servers with issues
    $serversExceedingUptime = ($results | Where-Object { $_.ExceedsUptimeLimit -eq $true } | Measure-Object).Count
    $serversExceedingCPU = ($results | Where-Object { $_.ExceedsCPULimit -eq $true } | Measure-Object).Count
    $serversExceedingMemory = ($results | Where-Object { $_.ExceedsMemoryLimit -eq $true } | Measure-Object).Count
    $offlineServers = ($results | Where-Object { $_.ConnectionStatus -eq "Server Offline" } | Measure-Object).Count
    $unregisteredServers = ($results | Where-Object { $_.RegistrationState -eq "Unregistered" } | Measure-Object).Count

    # Generate HTML report
    $reportDate = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $html = @"
<!DOCTYPE html>
<html>
<head>
    <title>Citrix Server Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1, h2 {
            color: #0067b8;
        }
        .report-info {
            margin-bottom: 20px;
        }
        .summary {
            background-color: #f8f8f8;
            padding: 15px;
            border: 1px solid #ddd;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .issues-summary {
            background-color: #fff0f0;
            padding: 15px;
            border: 1px solid #ffcccc;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 40px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #0067b8;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .error {
            color: red;
        }
        .warning {
            color: orange;
        }
        .good {
            color: green;
        }
        .highlight-row {
            background-color: #fff0f0 !important;
        }
    </style>
</head>
<body>
    <h1>Citrix Server Report</h1>
    <div class="report-info">
        <p><strong>Report Generated:</strong> $reportDate</p>
        <p><strong>Thresholds:</strong> CPU: $CpuThreshold%, Memory: $MemoryThreshold%, Uptime: $UptimeThreshold hours</p>
        <p><strong>Drive Space Check Servers:</strong> $($DriveCheckServers -join ', ')</p>
    </div>
    
    <div class="summary">
        <h2>Environment Summary</h2>
        <p><strong>Active Sessions:</strong> $activeCount</p>
        <p><strong>Disconnected Sessions:</strong> $disconnectedCount</p>
        <p><strong>Total Sessions:</strong> $($activeCount + $disconnectedCount)</p>
        <p><strong>Registered Desktops:</strong> $regCount</p>
        <p><strong>Unregistered Desktops:</strong> $unregCount</p>
    </div>
    
    <div class="issues-summary">
        <h2>Issues Summary</h2>
        <p><strong>Servers Exceeding Uptime Limit ($UptimeThreshold hours):</strong> $serversExceedingUptime</p>
        <p><strong>Servers Exceeding CPU Threshold ($CpuThreshold%):</strong> $serversExceedingCPU</p>
        <p><strong>Servers Exceeding Memory Threshold ($MemoryThreshold%):</strong> $serversExceedingMemory</p>
        <p><strong>Offline Servers:</strong> $offlineServers</p>
        <p><strong>Unregistered Servers:</strong> $unregisteredServers</p>
    </div>
"@

    # Add table for servers with drive space check
    if ($serversWithDriveCheck.Count -gt 0) {
        $html += @"
    <h2>Servers With Drive Space Monitoring</h2>
    <table>
        <tr>
            <th>Server Name</th>
            <th>Ping Response</th>
            <th>Active Sessions</th>
            <th>Disconnected Sessions</th>
            <th>Total Sessions</th>
            <th>Registration State</th>
            <th>CPU Usage (%)</th>
            <th>Memory Usage</th>
            <th>E: Drive Used (GB)</th>
            <th>E: Drive Free (GB)</th>
            <th>Last Boot Time</th>
            <th>Uptime</th>
        </tr>
"@

        foreach ($result in $serversWithDriveCheck) {
            # Add color coding based on status
            $cpuClass = if ($result.CPUUsage -ne "N/A" -and $result.CPUUsage -ne "Error") {
                if ([double]::TryParse($result.CPUUsage, [ref]$null)) {
                    if ([double]$result.CPUUsage -gt $CpuThreshold) { "error" } 
                    elseif ([double]$result.CPUUsage -gt ($CpuThreshold * 0.8)) { "warning" } 
                    else { "good" }
                } else { "" }
            } else { "" }
            
            $registrationClass = if ($result.RegistrationState -eq "Registered") { "good" } 
                                elseif ($result.RegistrationState -eq "Unknown" -or $result.RegistrationState -eq "Error") { "" }
                                else { "error" }
            
            $uptimeClass = if ($result.UptimeHours -ne "N/A" -and $result.UptimeHours -ne "Error") {
                if ([double]::TryParse($result.UptimeHours, [ref]$null)) {
                    if ([double]$result.UptimeHours -gt $UptimeThreshold) { "error" } else { "good" }
                } else { "" }
            } else { "" }

            # Determine if the row should be highlighted due to issues
            $rowClass = if ($result.ExceedsUptimeLimit -or $result.ExceedsCPULimit -or $result.ExceedsMemoryLimit -or 
                            $result.ConnectionStatus -eq "Server Offline" -or $result.RegistrationState -eq "Unregistered") {
                "highlight-row"
            } else {
                ""
            }
 
            $html += @"
<tr class="$rowClass">
<td>$($result.ServerName)</td>
<td>$($result.PingResponseTime)</td>
<td>$($result.ActiveSessions)</td>
<td>$($result.DisconnectedSessions)</td>
<td>$($result.TotalSessions)</td>
<td class="$registrationClass">$($result.RegistrationState)</td>
<td class="$cpuClass">$($result.CPUUsage)</td>
<td>$($result.MemoryUsage)</td>
<td>$($result.EDriveUsedGB)</td>
<td>$($result.EDriveFreeGB)</td>
<td>$($result.LastBootTime)</td>
<td class="$uptimeClass">$($result.UptimeDays)</td>
</tr>
"@
        }
        $html += @"
</table>
"@
    }
    # Add table for servers without drive space check
    if ($serversWithoutDriveCheck.Count -gt 0) {
        $html += @"
<h2>Other Monitored Servers</h2>
<table>
<tr>
<th>Server Name</th>
<th>Ping Response</th>
<th>Active Sessions</th>
<th>Disconnected Sessions</th>
<th>Total Sessions</th>
<th>Registration State</th>
<th>CPU Usage (%)</th>
<th>Memory Usage</th>
<th>Last Boot Time</th>
<th>Uptime</th>
</tr>
"@
 
        foreach ($result in $serversWithoutDriveCheck) {
            # Add color coding based on status
            $cpuClass = if ($result.CPUUsage -ne "N/A" -and $result.CPUUsage -ne "Error") {
                if ([double]::TryParse($result.CPUUsage, [ref]$null)) {
                    if ([double]$result.CPUUsage -gt $CpuThreshold) { "error" } 
                    elseif ([double]$result.CPUUsage -gt ($CpuThreshold * 0.8)) { "warning" } 
                    else { "good" }
                } else { "" }
            } else { "" }
            $registrationClass = if ($result.RegistrationState -eq "Registered") { "good" } 
                                elseif ($result.RegistrationState -eq "Unknown" -or $result.RegistrationState -eq "Error") { "" }
                                else { "error" }
            $uptimeClass = if ($result.UptimeHours -ne "N/A" -and $result.UptimeHours -ne "Error") {
                if ([double]::TryParse($result.UptimeHours, [ref]$null)) {
                    if ([double]$result.UptimeHours -gt $UptimeThreshold) { "error" } else { "good" }
                } else { "" }
            } else { "" }
 
            # Determine if the row should be highlighted due to issues
            $rowClass = if ($result.ExceedsUptimeLimit -or $result.ExceedsCPULimit -or $result.ExceedsMemoryLimit -or 
                            $result.ConnectionStatus -eq "Server Offline" -or $result.RegistrationState -eq "Unregistered") {
                "highlight-row"
            } else {
                ""
            }
 
            $html += @"
<tr class="$rowClass">
<td>$($result.ServerName)</td>
<td>$($result.PingResponseTime)</td>
<td>$($result.ActiveSessions)</td>
<td>$($result.DisconnectedSessions)</td>
<td>$($result.TotalSessions)</td>
<td class="$registrationClass">$($result.RegistrationState)</td>
<td class="$cpuClass">$($result.CPUUsage)</td>
<td>$($result.MemoryUsage)</td>
<td>$($result.LastBootTime)</td>
<td class="$uptimeClass">$($result.UptimeDays)</td>
</tr>
"@
        }
        $html += @"
</table>
"@
    }
    # Close HTML document
    $html += @"
</body>
</html>
"@

    # Save report to file with timestamp
    $timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $reportFile = Join-Path -Path $outputFolderPath -ChildPath "CitrixReport-$timestamp.html"
    try {
        $html | Out-File -FilePath $reportFile -Encoding UTF8 -Force
        Write-Output "Report saved to: $reportFile"
    } catch {
        Write-Error "Failed to save report to ${reportFile}: $($_.Exception.Message)"
    }

    # Return results for further processing if needed
    return $results
}

# Example of how to use the function
Start-CitrixMonitoring  -ServersFilePath $ServersFilePath -ConfigFilePath $ConfigFilePath -Verbose
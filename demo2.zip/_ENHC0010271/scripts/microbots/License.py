import datetime

def license_check():
    try:
        # Expiry date of the bot
        expiry_date = datetime.date(2024, 12, 31)
        
        # Get the current date
        current_date = datetime.date.today()
        
        # Check if the current date is before the expiry date
        if current_date <= expiry_date:
            return True, 'License is valid.'
        else:
            return False, 'License for this bot has expired.'
    except Exception as e:
        return False, f'Error validating license: {e}'

# Call the function and print the returned values
is_valid, message = license_check()
print(message)
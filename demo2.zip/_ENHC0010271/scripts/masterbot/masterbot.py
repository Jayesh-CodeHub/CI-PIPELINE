import paramiko
import openpyxl
import win32cred
import os
import sys
import json
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

#########################################################################################################################
sys.path.append(os.path.dirname(os.path.dirname(os.getcwd())))
parent_directory = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
config_file_path = os.path.join(parent_directory, "Conf", "config.json")
from scripts.microbots.License import license_check
#########################################################################################################################

# Define the list of commands 
commands = [
    "rows 0",
    "system health status show",
    "storage shelf show -connectivity",
    "storage disk show -broken",
    "system health alert show -instance",
    "network port show",
    "network interface show -status",
    "network interface show -status-oper down",
    "volume show -state !online",
    "snapmirror show -healthy false"
]

def get_credentials():
    try:
        # Get license validation result first
        is_valid, message = license_check()
        if not is_valid:
            print(message)
            return None, None, False
            
        # Fetch the credentials from the Windows Credential Manager
        creds = win32cred.CredRead("Matalan", win32cred.CRED_TYPE_GENERIC, 0)
        username = creds['UserName']
        password = creds['CredentialBlob']
        return username, password.decode('utf-16'), True
    except Exception as e:
        print(f"Error retrieving credentials: {str(e)}")
        return None, None, False

def ssh_connect(server_ip, username, password, log_file, report_file):
    # Skip empty server IPs
    if not server_ip:
        error_msg = f"{datetime.now()} - Error: Skipping empty server IP\n"
        log_file.write(error_msg)
        print(error_msg)
        return False
        
    try:
        # Create SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect to the server using the IP address directly
        ssh_client.connect(hostname=server_ip, username=username, password=password)

        # Log connection details and print to console
        connection_msg = f"{datetime.now()} - Connected to {server_ip}\n"
        log_file.write(connection_msg)
        print(connection_msg)

        # Execute commands on the server
        for command in commands:
            command_msg = f"{datetime.now()} - Executing command on {server_ip}: {command}\n"
            log_file.write(command_msg)
            print(command_msg)
            
            stdin, stdout, stderr = ssh_client.exec_command(command)
            output = ''.join(stdout.readlines())
            write_to_report(report_file, server_ip, command, output)
            print(output)  # Print output to console

        # Close the SSH connection
        ssh_client.close()

    except Exception as e:
        error_msg = f"{datetime.now()} - Error connecting to {server_ip}: {str(e)}\n"
        log_file.write(error_msg)
        print(error_msg)
        return False  # Return False if there was an error connecting

    return True  # Return True if connected successfully

def write_to_report(report_file, server_ip, command, output):
    # Define keywords and their corresponding highlight colors
    highlight_mapping = {
        "ok": "#00FF00",  # Green
        "healthy": "#00FF00",  # Green
        "up": "#00FF00",  # Green
        "down": "#FF0000",  # Red
        "active": "green"
    }

    # Apply highlighting to the output
    for keyword, color in highlight_mapping.items():
        output = output.replace(keyword, f"<span style='background-color: {color};'>{keyword}</span>")
    
    # Wrap the output in a <pre> tag to preserve formatting
    output = f"<pre>{output}</pre>"

    # Write to the report file
    report_file.write("<tr>")
    report_file.write(f"<td>{server_ip}</td>")
    report_file.write(f"<td>{command}</td>")
    report_file.write(f"<td>{output}</td>")
    report_file.write("</tr>\n")


def send_email(subject, body, attachment_path):
    try:
        # Load email configuration from config.json
        with open(config_file_path) as f:
            config_data = json.load(f)
            email_config = config_data.get("email_config")

        if not email_config:
            print("Email configuration not found in config.json")
            return
            
        # Email configuration
        sender_email = email_config.get("sender_email")
        receiver_email = email_config.get("receiver_email")
        smtp_server = email_config.get("smtp_server")
        smtp_port = email_config.get("smtp_port")
        #smtp_username = email_config.get("smtp_username")
        #smtp_password = email_config.get("smtp_password")

        # Create a multipart message and set headers
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject

        # Add body to email
        message.attach(MIMEText(body, "plain"))

        # Open the file to be sent
        with open(attachment_path, "rb") as attachment:
            # Add file as application/octet-stream
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())

            # Encode file in ASCII characters to send by email    
            encoders.encode_base64(part)

            # Add header as key/value pair to attachment part
            part.add_header(
                "Content-Disposition",
                f"attachment; filename= {os.path.basename(attachment_path)}",
            )

            # Add attachment to message and convert message to string
            message.attach(part)
            text = message.as_string()

            # Send email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                #server.login(smtp_username, smtp_password)
                server.sendmail(sender_email, receiver_email, text)

            print(f"Email sent successfully to {receiver_email}")

    except Exception as e:
        print(f"Error sending email: {str(e)}")

def main():
    try:
        # First check if license is valid
        is_valid, message = license_check()
        if not is_valid:
            print(message)
            # Send email notification about expired license
            log_file_path = os.path.join(parent_directory, "log", "log.txt")
            with open(log_file_path, "w") as log_file:
                log_file.write(f"{datetime.now()} - {message}\n")
            send_email("Matalan NetApp Health-Check License Expired", 
                      "The license for NetApp Health-Check has expired. Please renew your license to continue using this service.", 
                      log_file_path)
            return  # Exit the function if license is not valid
            
        execution_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Make sure the log and output directories exist
        log_dir = os.path.join(parent_directory, "log")
        output_dir = os.path.join(parent_directory, "output")
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)
        
        # Load Excel file
        excel_file = os.path.join(parent_directory, "input", "server_details.xlsx")  # Change this to your Excel file path
        if not os.path.exists(excel_file):
            print(f"Error: Excel file not found at {excel_file}")
            return
            
        wb = openpyxl.load_workbook(excel_file)
        sheet = wb.active
 
        # Get credentials from Windows Credential Manager
        username, password, credentials_valid = get_credentials()
        
        if not credentials_valid:
            print("Failed to get valid credentials. Exiting.")
            return

        # Flag to track if there was any connection error
        connection_error = False
 
        # Open log file in write mode (overwrite existing content)
        log_file_path = os.path.join(log_dir, "log.txt")
        with open(log_file_path, "w") as log_file:
            # Open report file in write mode
            report_file_path = os.path.join(output_dir, "report.html")
            with open(report_file_path, "w") as report_file:
                # Write HTML header to report file
                report_file.write(f"<html><head><title>NetApp Health-Check Report - {execution_time}</title>")
                report_file.write("<style>")
                report_file.write("table {border-collapse: collapse; width: 100%;}")
                report_file.write("th, td {padding: 15px; text-align: left;}")
                report_file.write("th {background-color: #4CAF50; color: white;}")
                report_file.write("tr:nth-child(even) {background-color: #f2f2f2;}")
                report_file.write(".red {color: red;}")  # Define style for red class
                report_file.write(".green {color: green;}")  # Define style for green class
                report_file.write("</style>")
                report_file.write("</head><body>")
                report_file.write(f"<h1>Matalan NetApp Health-Check Report - {execution_time}</h1>")
                report_file.write("<table border='1' cellpadding='10'>")
                report_file.write("<tr><th>Server IP</th><th>Command</th><th>Output</th></tr>")
                
                # Flag to keep track if we processed any servers
                servers_processed = False
                
                # Iterate through rows and connect to servers
                for row in sheet.iter_rows(min_row=2, values_only=True):
                    if not row or len(row) < 1 or not row[0]:  # Skip empty rows or rows without IP
                        continue
                        
                    server_ip = row[0]  # Assuming IP addresses are in the first column
                    if not server_ip or server_ip == "None" or server_ip == "":
                        continue  # Skip empty IP addresses
                        
                    servers_processed = True
                    # Connect to the server and execute commands
                    connected = ssh_connect(server_ip, username, password, log_file, report_file)
                    # Check if there was an error connecting to the server
                    if not connected:
                        connection_error = True
                
                # Close HTML tags
                report_file.write("</table></body></html>")
                
        # If no servers were processed, log an error
        if not servers_processed:
            with open(log_file_path, "a") as log_file:
                error_msg = f"{datetime.now()} - Error: No valid server IPs found in the Excel file\n"
                log_file.write(error_msg)
                print(error_msg)
            connection_error = True
                
        # If there was a connection error, send the error email with log.txt
        if connection_error:
            send_email("Matalan NetApp Health-Check Report", "There was an error connecting to one or more servers. Please check the log file for details.", log_file_path)
        # If there was no connection error, send the report email with report.html
        else:
            send_email("Matalan NetApp Health-Check Report", "Please find attached the NetApp Health-Check Report.", report_file_path)

    except Exception as e:
        print(f"Error: {str(e)}")
        # Make sure the log directory exists
        log_dir = os.path.join(parent_directory, "log")
        os.makedirs(log_dir, exist_ok=True)
        
        with open(os.path.join(log_dir, "log.txt"), "a") as log_file:
            log_file.write(f"{datetime.now()} - Error: {str(e)}\n")

if __name__ == "__main__":
    main()
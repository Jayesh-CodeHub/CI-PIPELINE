def license():
    BotID = "ENHC0010271"
    BotName = "ENHC0010206_Matalan_Netapp_Storage_HealthCheck"
    ExpiryDate = "01-02-2025"           #Must be in dd-MM-yyyy format
    return BotID, BotName, ExpiryDate
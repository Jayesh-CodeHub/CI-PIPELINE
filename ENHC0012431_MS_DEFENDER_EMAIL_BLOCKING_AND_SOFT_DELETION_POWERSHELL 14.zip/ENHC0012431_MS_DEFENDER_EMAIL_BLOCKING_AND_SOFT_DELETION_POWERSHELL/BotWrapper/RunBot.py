# import os
# import subprocess
# from cryptography.fernet import Fernet

# # Define paths
# wrapper_dir = os.path.dirname(__file__)
# base_path = os.path.abspath(os.path.join(wrapper_dir, ".."))
# print(f"Using BasePath = {base_path}")

# # Load Fernet key from BotWrapper folder
# key_path = os.path.join(wrapper_dir, "key.key")
# with open(key_path, "rb") as kf:
#     key = kf.read()
# fernet = Fernet(key)

# # ========================
# # 1. Decrypt MasterBot
# # ========================
# enc_master_path = os.path.join(wrapper_dir, "EncryptedMasterBot.bin")
# with open(enc_master_path, "rb") as emf:
#     encrypted_master = emf.read()

# decrypted_master = fernet.decrypt(encrypted_master)

# # Write decrypted masterbot temporarily
# masterbot_dir = os.path.join(base_path, "scripts", "MasterBot")
# os.makedirs(masterbot_dir, exist_ok=True)
# wrapped_master_path = os.path.join(masterbot_dir, "wrapped_masterbot.ps1")
# with open(wrapped_master_path, "wb") as wf:
#     wf.write(decrypted_master)
# print(f"Decrypted script written to: {wrapped_master_path}")

# # ========================
# # 2. Decrypt MicroBots
# # ========================
# microbots_dir = os.path.join(base_path, "scripts", "MicroBots")
# os.makedirs(microbots_dir, exist_ok=True)

# for filename in os.listdir(wrapper_dir):
#     if filename.startswith("Encrypted_") and filename.endswith(".bin"):
#         # Derive original script name (e.g., Encrypted_EnE.ps1.bin → EnE.ps1)
#         original_name = filename.replace("Encrypted_", "").replace(".bin", "")
#         encrypted_path = os.path.join(wrapper_dir, filename)
#         decrypted_path = os.path.join(microbots_dir, original_name)

#         # Decrypt and save
#         with open(encrypted_path, "rb") as ef:
#             encrypted_data = ef.read()
#         decrypted_data = fernet.decrypt(encrypted_data)

#         with open(decrypted_path, "wb") as df:
#             df.write(decrypted_data)
#         print(f"Decrypted MicroBot: {decrypted_path}")

# # ========================
# # 3. Run MasterBot
# # ========================
# ps_cmd = [
#     "powershell.exe",
#     "-NoProfile",
#     "-ExecutionPolicy", "Bypass",
#     "-File", wrapped_master_path,
#     base_path
# ]

# result = subprocess.run(ps_cmd, capture_output=True, text=True)
# print(result.stdout)
# if result.stderr:
#     print("Errors:", result.stderr)

# # ========================
# # 4. Cleanup ONLY MasterBot temp
# # ========================
# if os.path.exists(wrapped_master_path):
#     os.remove(wrapped_master_path)
#     print(f"Removed wrapped MasterBot: {wrapped_master_path}")

# # Note: MicroBots are **NOT** deleted here. You can delete them manually post-training.
import os
import subprocess
from cryptography.fernet import Fernet

# Define paths
wrapper_dir = os.path.dirname(__file__)
base_path = os.path.abspath(os.path.join(wrapper_dir, ".."))
print(f"Using BasePath = {base_path}")

# Load Fernet key from BotWrapper folder
key_path = os.path.join(wrapper_dir, "key.key")
with open(key_path, "rb") as kf:
    key = kf.read()
fernet = Fernet(key)

# ========================
# 1. Decrypt MasterBot
# ========================
enc_master_path = os.path.join(wrapper_dir, "EncryptedMasterBot.bin")
with open(enc_master_path, "rb") as emf:
    encrypted_master = emf.read()

decrypted_master = fernet.decrypt(encrypted_master)

# Write decrypted masterbot temporarily
masterbot_dir = os.path.join(base_path, "scripts", "MasterBot")
os.makedirs(masterbot_dir, exist_ok=True)
wrapped_master_path = os.path.join(masterbot_dir, "wrapped_masterbot.ps1")
with open(wrapped_master_path, "wb") as wf:
    wf.write(decrypted_master)
print(f"Decrypted script written to: {wrapped_master_path}")

# ========================
# 2. Decrypt MicroBots
# ========================
microbots_dir = os.path.join(base_path, "scripts", "MicroBots")
os.makedirs(microbots_dir, exist_ok=True)

# Track decrypted MicroBots to delete later
decrypted_microbots = []

for filename in os.listdir(wrapper_dir):
    if filename.startswith("Encrypted_") and filename.endswith(".bin"):
        # Derive original script name (e.g., Encrypted_EnE.ps1.bin → EnE.ps1)
        original_name = filename.replace("Encrypted_", "").replace(".bin", "")
        encrypted_path = os.path.join(wrapper_dir, filename)
        decrypted_path = os.path.join(microbots_dir, original_name)

        # Decrypt and save
        with open(encrypted_path, "rb") as ef:
            encrypted_data = ef.read()
        decrypted_data = fernet.decrypt(encrypted_data)

        with open(decrypted_path, "wb") as df:
            df.write(decrypted_data)
        print(f"Decrypted MicroBot: {decrypted_path}")

        # Track for deletion
        decrypted_microbots.append(decrypted_path)

# ========================
# 3. Run MasterBot
# ========================
ps_cmd = [
    "powershell.exe",
    "-NoProfile",
    "-ExecutionPolicy", "Bypass",
    "-File", wrapped_master_path,
    base_path
]

result = subprocess.run(ps_cmd, capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("Errors:", result.stderr)

# ========================
# 4. Cleanup decrypted scripts
# ========================

# Delete MasterBot
if os.path.exists(wrapped_master_path):
    os.remove(wrapped_master_path)
    print(f"Removed wrapped MasterBot: {wrapped_master_path}")

# Delete MicroBots
for microbot_path in decrypted_microbots:
    if os.path.exists(microbot_path):
        os.remove(microbot_path)
        print(f"Removed decrypted MicroBot: {microbot_path}")

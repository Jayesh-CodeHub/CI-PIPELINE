import os
from cryptography.fernet import Fernet

# Load the key
with open("key.key", "rb") as kf:
    key = kf.read()
fernet = Fernet(key)

def encrypt_file(path, output_file):
    with open(path, "rb") as f:
        encrypted = fernet.encrypt(f.read())
    with open(output_file, "wb") as ef:
        ef.write(encrypted)
    print(f"{output_file} written")

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# MasterBot encryption
master_path = os.path.join(base_dir, "scripts", "MasterBot", "ms_defender_email_blocking_and_soft_deletion.ps1")
encrypt_file(master_path, os.path.join("EncryptedMasterBot.bin"))

# MicroBots encryption
microbots_dir = os.path.join(base_dir, "scripts", "MicroBots")
for filename in os.listdir(microbots_dir):
    if filename.endswith(".ps1"):
        file_path = os.path.join(microbots_dir, filename)
        output_file = os.path.join(f"Encrypted_{filename}.bin")
        encrypt_file(file_path, output_file)


############### define param block ###############
param (
    [Parameter(Mandatory = $true)]
    [string]$LogFileName,

    [Parameter(Mandatory = $true)]
    [string]$LogMessage
)
##################################################

############### define folder path ###############
try {
    $botFolderPath = (Resolve-Path "..\..\").Path
    $logFolderPath = Join-Path -Path $botFolderPath -ChildPath "log"
}
catch {
    Write-Output "ERROR - (Log-Entry) - $($_)"
}
#################################################

########### create new date log folder ##########
try {
    # define date-wise log folder path
    $dateWiseLogFolderPath = Join-Path -Path $logFolderPath -ChildPath $((Get-Date).ToString("dd-MMM-yyyy"))
    # if the folder is not present
    if (-not (Test-Path $dateWiseLogFolderPath)) {
        # create new folder
        New-Item -Path $dateWiseLogFolderPath -ItemType Directory | Out-Null
        # check if the folder create
        if (-not (Test-Path $dateWiseLogFolderPath)) {
            Write-Output "ERROR - (Log-Entry) - log\$((Get-Date).ToString('dd-MMM-yyyy')) Not Created"
        }
        else {
            # define new log file path
            $logFilePath = Join-Path -Path $dateWiseLogFolderPath -ChildPath $LogFileName
        }
    }
    else {
        # define new log file path
        $logFilePath = Join-Path -Path $dateWiseLogFolderPath -ChildPath $LogFileName
    }
}
catch {
    Write-Output "ERROR - (Log-Entry) - $($_)"
}
#################################################

######### appending data into log file ##########
try {
    Add-Content -Path $logFilePath -Value "$(Get-Date -Format "MM-dd-yyyy - HH:mm:ss") -- $($LogMessage)"
}
catch {
    Write-Output "ERROR - (Log-Entry) - $($_)"
}
#################################################
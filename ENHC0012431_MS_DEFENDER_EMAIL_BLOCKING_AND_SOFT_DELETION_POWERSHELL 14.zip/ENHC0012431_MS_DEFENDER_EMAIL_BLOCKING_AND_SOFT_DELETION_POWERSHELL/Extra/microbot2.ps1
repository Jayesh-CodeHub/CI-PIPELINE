# Requires -Modules ExchangeOnlineManagement, ImportExcel
[CmdletBinding()]
param (
    [string]$inputfilepath,
    [string]$LogEntry,
    [string]$logFileName,
    [string]$outputFolderPath,
    [string]$VerificationDelay,
    [string]$EnEBot
)
# -------------------------------
# Connectivity Functions
# -------------------------------
function Connect-ToExchange {
    try {
        Write-Host "`n[Step 1] Connecting to Exchange Online..." -ForegroundColor Cyan
        Connect-ExchangeOnline -ShowBanner:$false
        Write-Host "[Success] Connected to Exchange Online!" -ForegroundColor Green
        & $LogEntry -LogFileName $logFileName -LogMessage "[Success] Connected to Exchange Online!"
        & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "ConnectionCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAS" -subexec_status "LVS" -bot_log ($CurrentTime + "[Success] Connected to Exchange Online!") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
        return $true
    }
    catch {
        Write-Host ("[Error] Failed to connect to Exchange Online: $($($_.Exception.Message))") -ForegroundColor Red
        & $LogEntry -LogFileName $logFileName -LogMessage "[Error] Failed to connect to Exchange Online: $($($_.Exception.Message))"
        & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "ConnectionCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAF" -subexec_status "LVF" -bot_log ($CurrentTime + "[Error] Failed to connect to Exchange Online: $($($_.Exception.Message))") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
        return $false
    }
}


# -------------------------------
# Blocking Function (Simplified)
# -------------------------------
function Block-Sender {
    param($SenderEmail)
    try {
        Write-Host "Blocking sender: $SenderEmail" -ForegroundColor Yellow
        & $LogEntry -LogFileName $logFileName -LogMessage "Blocking sender: $SenderEmail"
        New-TenantAllowBlockListItems -ListType Sender -Block -Entries $SenderEmail -ErrorAction SilentlyContinue | Out-Null
        Write-Host "Successfully blocked sender: $SenderEmail" -ForegroundColor Green
        & $LogEntry -LogFileName $logFileName -LogMessage "Successfully blocked sender: $SenderEmail"
        & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "BlockEmailCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAS" -subexec_status "LVS" -bot_log ($CurrentTime + "Successfully blocked sender: $SenderEmail") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
        return $true
    }
    catch {
        Write-Host ("[Error] Failed to block sender $SenderEmail : $($($_.Exception.Message))") -ForegroundColor Red
        & $LogEntry -LogFileName $logFileName -LogMessage "[Error] Failed to block sender $SenderEmail : $($($_.Exception.Message))"
        & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "BlockEmailCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAF" -subexec_status "LVF" -bot_log ($CurrentTime + "[Error] Failed to block sender $SenderEmail : $($($_.Exception.Message))") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
        return $false
    }
}


# -------------------------------
# Main Function: Start-EmailSecurityAutomation
# -------------------------------
function Start-EmailSecurityAutomation {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ExcelFilePath,
        [Parameter(Mandatory = $true)]
        [int]$VerificationDelay,
        [Parameter(Mandatory = $true)]
        [string]$outputFolderPath
    )

    # Connect to Exchange Online and Compliance Center
    if (-not (Connect-ToExchange)) {
        throw "Exchange Online connection failed. Exiting script."
    }
   
    Write-Host "`n[Step 6] Importing email data from Excel file: $ExcelFilePath" -ForegroundColor Cyan
    & $LogEntry -LogFileName $logFileName -LogMessage "`n[Step 6] Importing email data from Excel file: $ExcelFilePath"
    try {
        $data = Import-Excel -Path $ExcelFilePath
    }
    catch {
        Write-Host ("[Error] Failed to read Excel file: $($($_.Exception.Message))") -ForegroundColor Red
        & $LogEntry -LogFileName $logFileName -LogMessage "[Error] Failed to read Excel file: $($($_.Exception.Message))"
        exit
    }

    # Initialize global results array
    $global:automationResults = @()

    Write-Host "`n================== Phase 1: Blocking and Soft Deletion ==================" -ForegroundColor Magenta

    $rowNumber = 1
    foreach ($row in $data) {
        $RecipientEmail = $row.RecipientEmail.ToString().Trim()
        $SenderEmail = $row.SenderEmail.ToString().Trim()

        Write-Host "`n========================================="
        Write-Host "Processing Row $rowNumber" -ForegroundColor Cyan
        Write-Host "Recipient: $RecipientEmail"
        Write-Host "Sender: $SenderEmail"
        Write-Host "=========================================`n"

        # Per-row validation: Check for a basic email format.
        if (-not ($RecipientEmail -match "^[\w\.-]+@[\w\.-]+\.\w+$" -and $SenderEmail -match "^[\w\.-]+@[\w\.-]+\.\w+$")) {
            Write-Host "[Error] Invalid email format for Row $rowNumber. Skipping row." -ForegroundColor Red
            $global:automationResults += [PSCustomObject]@{
                RowNumber           = $rowNumber
                RecipientEmail      = $RecipientEmail
                SenderEmail         = $SenderEmail
                BlockStatus         = "Skipped"
            }
            $rowNumber++
            continue
        }

        # Block sender (always call new blocking)
        $blockSuccess = Block-Sender -SenderEmail $SenderEmail
        $blockMessage = if ($blockSuccess) { "Successfully blocked" } else { "Blocking failed" }
        Write-Host "Block Status: $blockMessage" -ForegroundColor $(if ($blockSuccess) { "Green" } else { "Red" })
        Start-Sleep -Seconds 10  # Delay between blocking and deletion

    

        # Save initial result (verification will be updated in phase 2)
        $global:automationResults += [PSCustomObject]@{
            RowNumber           = $rowNumber
            RecipientEmail      = $RecipientEmail
            SenderEmail         = $SenderEmail
            BlockStatus         = $blockMessage
        }

        $rowNumber++
        Start-Sleep -Seconds 10
    }

    Write-Host "`n================== Phase 1 Completed ==================" -ForegroundColor Magenta
   
    Write-Host "`n================== Phase 2: Verification ==================" -ForegroundColor Magenta

    

    # Export consolidated results to an Excel file
    $outputPath = Join-Path -Path $outputFolderPath -ChildPath "SecurityAutomation_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss').xlsx"
    $global:automationResults | Export-Excel -Path $outputPath -AutoSize -TableStyle Medium2 -WorksheetName "Results" -FreezeTopRow -AutoFilter
    Write-Host "`nResults exported to: $outputPath" -ForegroundColor Green
    & $LogEntry -LogFileName $logFileName -LogMessage "`nResults exported to: $outputPath"

    # Disconnect sessions
    Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue
    # Remove-PSSession -Name "PSSessionToComplianceCenter" -ErrorAction SilentlyContinue

    return $outputPath
}

# -------------------------------
# Example Usage
# -------------------------------
# Replace the Excel file path with your actual file path
$outputPath = Start-EmailSecurityAutomation -ExcelFilePath $inputfilepath -VerificationDelay $VerificationDelay -outputFolderPath $outputFolderPath
Write-Host "In microbot output path :$($outputPath)"
return $outputPath
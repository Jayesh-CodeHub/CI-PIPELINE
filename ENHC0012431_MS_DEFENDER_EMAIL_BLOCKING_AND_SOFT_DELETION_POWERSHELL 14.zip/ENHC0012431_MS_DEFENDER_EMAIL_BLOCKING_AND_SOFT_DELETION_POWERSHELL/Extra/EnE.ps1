Param(
     [parameter(Mandatory=$false) ]
  [string]$customer_short_name,
  [parameter(Mandatory=$false) ]
  [string]$ras_id,
  [parameter(Mandatory=$false) ]
  [string]$bot_id,
  [parameter(Mandatory=$false) ]
  [string]$solution,
  [parameter(Mandatory=$false) ]
  [string]$bot_name,
  [parameter(Mandatory=$false) ]
  [string]$region,
  [parameter(Mandatory=$false) ]
  [string]$itsm_customer,
  [parameter(Mandatory=$false) ]
  [string]$itsm_record,
  [parameter(Mandatory=$false) ]
  [string]$target_endpoint,
  [parameter(Mandatory=$false) ]
  [string]$source_system,
  [parameter(Mandatory=$false) ]
  [string]$execution_start_time,
        [parameter(Mandatory=$false) ]
        [string]$execution_end_time,
  [parameter(Mandatory=$false) ]
  [string]$execution_status,
  [parameter(Mandatory=$false) ]
  [string]$subexec_status,
  [parameter(Mandatory=$false) ]
  [string]$bot_log,
  [parameter(Mandatory=$false) ]
  [string]$bot_path,
  [parameter(Mandatory=$false) ]
  [string]$bot_hash,
  [parameter(Mandatory=$false) ]
  [string]$bot_version,
        [parameter(Mandatory=$false) ]
  [string]$run_id,
        [parameter(Mandatory=$false) ]
  [string]$onboarded_count,
  [parameter(Mandatory=$false) ]
  [string]$ene_folder_path
)

# Define paths for input
$CurrentTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$botFolderPath = (Resolve-Path "$PSScriptRoot\..\..").Path
$inputFolderPath = Join-Path -Path $botFolderPath -ChildPath "input"
$ene_input_Path = Join-Path -Path $inputFolderPath -ChildPath "ene_input.json"
$ene_input = Get-Content -Path $ene_input_Path | ConvertFrom-Json
$source_system = $env:COMPUTERNAME


try
{
    if(!($ene_folder_path.EndsWith("\")))
    {
            $ene_folder_path = $ene_folder_path + "\"
    }
    
    $year = (get-date).Year
    $month = (get-date).Month
    $month=(Get-Culture).DateTimeFormat.GetMonthName($month)
    $day = (get-date).Day
    $eneFolderPath = $ene_folder_path+"$year"+"\"+"$month"+"\"+"$day"
    $enefiledate = Get-Date -Format "yyyyMMddHHmm"
    $enecsv = $eneFolderPath+"\"+$run_id+"_EnEData.csv"
    $cMonth=(get-date).ToString('MM')
        
    $yday=(get-date).ToString('yyyy-MM-dd')

    $week=$yday | Get-Date -UFormat %V

    if(!(Test-Path $eneFolderPath))
    {
        mkdir $eneFolderPath | Out-Null
    }

        $eneObj = "" | select customer_short_name,ras_id,bot_id,solution,bot_name,region,itsm_customer,itsm_record,target_endpoint,source_system,execution_end_time,execution_status,subexec_status,bot_log,bot_path,bot_hash,bot_version,execution_start_time,run_id,Week,Month,onboarded_count
        
        $eneObj.customer_short_name = $ene_input.customer_short_name
        $eneObj.ras_id = $ene_input.ras_id
        $eneObj.region = $ene_input.region
        $eneObj.bot_id = $ene_input.bot_id
        $eneObj.bot_log = $CurrentTime + $bot_log
        $eneObj.source_system = $source_system
        $eneObj.bot_name = $bot_name
        $eneObj.bot_hash = $bot_hash
        $eneObj.itsm_record = "Scheduled"
        $eneObj.bot_path = $bot_path
        $eneObj.solution = $ene_input.solution
        $eneObj.itsm_customer = $ene_input.itsm_customer
        $eneObj.target_endpoint = $target_endpoint
        $eneObj.execution_start_time = $execution_start_time
        $eneObj.execution_end_time = $execution_end_time
        $eneObj.execution_status = $execution_status
        $eneObj.subexec_status = $subexec_status
        $eneObj.bot_version = $ene_input.bot_version
        $eneObj.run_id = $run_id
        $eneObj.Week = $week
        $eneObj.Month = $cMonth
        $eneObj.onboarded_count = $ene_input.onboarded_count
        $eneObj  |  Export-csv -Path $enecsv -NoTypeInformation -Append
    return $true
}
catch
{
    $failure = $_.exception.Message
    return $failure
}
 
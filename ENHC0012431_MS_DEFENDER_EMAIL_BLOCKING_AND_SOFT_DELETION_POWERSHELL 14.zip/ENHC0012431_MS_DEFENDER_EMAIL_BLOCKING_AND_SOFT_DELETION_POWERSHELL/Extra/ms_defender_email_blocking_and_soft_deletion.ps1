
param (
    [string]$BasePath
)

if (-not $BasePath) {
    Write-Output "BasePath not provided!"
    exit
}

# Use the passed‑in BasePath rather than Resolve-Path
$botFolderPath = (Resolve-Path "$PSScriptRoot\..\..").Path

# then replace your Resolve-Path logic:
############### define folder path ###############
try {
    $confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
    $configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
    $credsFolderPath = Join-Path -Path $confFolderPath -ChildPath "Creds"
    $licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
    $libFolderPath = Join-Path -Path $botFolderPath -ChildPath "lib"
    $logFolderPath = Join-Path -Path $botFolderPath -ChildPath "log"
    $inputFolderPath = Join-Path -Path $botFolderPath -ChildPath "input"
    $outputFolderPath = Join-Path -Path $botFolderPath -ChildPath "output"
    $scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
    $masterbotFolderPath = Join-Path -Path $botFolderPath -ChildPath "MasterBot"
    $microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"
    $inputfilepath = Join-Path -Path $inputFolderPath -ChildPath "defender.xlsx"
    $EnEBot = Join-Path -Path $microbotFolderPath -ChildPath "EnE.ps1"
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    exit
}

$ene_input_Path = Join-Path -Path $inputFolderPath -ChildPath "ene_input.json"
$ene_input = Get-Content -Path $ene_input_Path | ConvertFrom-Json
$enres = $ene_input
$local_host = hostname
$run_id = $local_host + "_" + (Get-Date -Format "yyyyMMddHHmmssfffff")
###################################################

########## importing pre-define microbot ##########
# define logentry microbot
try {
    # define logentry microbot file path
    $LogEntry = Join-Path -Path $microbotFolderPath -ChildPath "logentry.ps1"
    # if logentry microbot is not present
    if (-not (Test-Path $LogEntry)) {
        Write-Output "ERROR - (Master-BoT) - LogEntry MicroBoT File Is Not Present"
        exit
    }
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    exit
}

try {
    # define functional microbot file path
    $microbot = Join-Path -Path $microbotFolderPath -ChildPath "microbot2.ps1"
    # if functional microbot is not present
    if (-not (Test-Path $microbot)) {
        Write-Output "ERROR - (Master-BoT) - MicroBoT1 File Is Not Present"
        exit
    }
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    exit
}

##################################################

########## fetch data from config file ###########
try {
    # define config file path
    $configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
    # if config file is present
    if (Test-Path $configFilePath) {
        $configFile = Get-content -Path $configFilePath | ConvertFrom-Json
    }
    else {
        Write-Output "ERROR - (Master-BoT) - Configuration File Is Not Present"
        exit
    }
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    exit
}


##################################################

################ delete old log ##################
# if log folder is present
if (Test-Path $logFolderPath) {
    # checking if the folder is not empty
    if ([int](Get-ChildItem -Path $logFolderPath -Directory).Count -gt 0) {
        # fetching all the folders details
        $logFolders = Get-ChildItem -Path $logFolderPath -Directory
        # if delete old log files days configured
        if ([string]$configFile.DeleteOldLogDays -ne "") {
            # loop through all the folders
            foreach ($folder in $logFolders) {
                # if folder is older that defined date
                if (($folder.CreationTime) -lt ((Get-Date).AddHours(-[int]$configFile.DeleteOldLogDays))) {
                    try {
                        Remove-Item -Path $folder.FullName -Recurse -Force
                    }
                    catch {
                        Write-Output "ERROR - (Master-BoT) - $($_)"
                    }
                }
            }
        }
        # if delete old log files days not configured
        else {
            # loop through all the folder
            foreach ($folder in $logFolders) {
                # if folder is older that defined date
                if (($folder.CreationTime) -lt ((Get-Date).AddHours(-30))) {
                    try {
                        Remove-Item -Path $folder.FullName -Recurse -Force
                    }
                    catch {
                        Write-Output "ERROR - (Master-BoT) - $($_)"
                    }
                }
            }
        }
    }
}
##################################################

############## define log-file name ##############
try {
    # sleep the script for 1-second
    Start-Sleep -Seconds 1
    $logFileName = (Get-Date).ToString('HH-mm-ss') + "_" + $configFile.LogFileName
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    exit
}
##################################################

############ checking license file ###############
# define constant
$licesneFileStatus = $false
$keyGenerateStatus = $false
$decryptKeyStatus = $false
$decryptLicenseDataStatus = $false
$decryptVariableStatus = $false

# define license file
try {
    # define bot folder path
    $botFolderPath = (Resolve-Path "$PSScriptRoot\..\..").Path
    # define conf folder path
    $confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
    # define license folder path
    $licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
    # define license file path
    $licenseFilePath = Join-Path -Path $licenseFolderPath -ChildPath "license"
    # check if the license file is present or not
    if (Test-Path $licenseFilePath) {
        # checking if the license file is not empty
        if ($licenseFilePath.Length -gt 0) {
            $licesneFileStatus = $true
        }
        else {
            $licesneFileStatus = $false
            Write-Output "ERROR - (Master-BoT) - License File Is Empty"
            & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - License File Is Empty"
            exit
        }
    }
    else {
        $licesneFileStatus = $false
        Write-Output "ERROR - (Master-BoT) - License File Not Present"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - License File Not Present"
        exit
    }
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
    & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
    exit
}

# define license key
if ($licesneFileStatus) {
    try {
        # define secret key
        $secretKey = (1..32)
        # converting license key to secure key
        [System.Security.SecureString]$secureKey = "76492d1116743f0423413b16050a5345MgB8AHgAYgBIAHIAaQBWADYANQA3ADYAQQBzAFQAMQBTAEYAYwBiAEgAZABYAGcAPQA9AHwAMwBlADkAMwBhADMANgBkAGYAOQA1ADcAOQBlADYANgAwADIANABlADUANQBlAGMAMwA0ADYAMABiAGEAZAA5ADEAMAAwAGEAZgAxADEAYgBiADgAYwAyADMAZABiAGMAOQBhADIAMwBhADgAMAAxADAAMwBkAGYANgBkADQANwA4ADEAOQBjADAAMAA1AGUAYwA2ADQAZgBiAGYAMwAwAGYANgA1ADEAYwBlAGIANABiAGMAYgA1ADQANAA2ADcAYwAzADAAZQAzADMAZAA5ADAANgA3AGUAZQAzADYANwBkADQAYQA1AGIAOQBkAGYANwBmAGQAOQAxADgAMwA3AGUAZQBjADgAZABlADUANgAwADMAMQAyADEANgBlAGQAMgAwADQAYgA0ADkAOAAxAGEANgBjADkAZAA4AGYAYgA2ADEAYgAyAGQAMwA5AGIAMAAxAGUAYwBjADMANAA2AGEAZgA3ADcANwA1AGYAMQBmAGUAMwAwADEAOAAzADYA" | ConvertTo-SecureString -Key $secretKey
        $keyGenerateStatus = $true
    }
    catch {
        Write-Output "ERROR - (Master-BoT) - $($_)"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
        exit
    }
}
else {
    exit
}

# decrypt secure key
if ($keyGenerateStatus) {
    try {
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
        $encryptionKey = [System.Convert]::FromBase64String([System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr))
        $crypto = [System.Security.Cryptography.SymmetricAlgorithm]::Create('AES')
        $crypto.KeySize = $encryptionKey.Length * 8
        $crypto.Key = $encryptionKey
        $fileStreamReader = New-Object System.IO.FileStream($licenseFilePath, [System.IO.FileMode]::Open)
        $decryptKeyStatus = $true
    }
    catch {
        Write-Output "ERROR - (Master-BoT) - $($_)"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
        exit
    }
}
else {
    exit
}

# decrypt license data
if ($decryptKeyStatus) {
    try {
        # intialize iv-block legth
        [Byte[]]$lenIV = New-Object Byte[] 4
        # reading iv-block from license file
        $fileStreamReader.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
        $fileStreamReader.Read($lenIV, 0, 3) | Out-Null
        [Int]$liv = [System.BitConverter]::ToInt32($lenIV, 0)
        # intialize iv-block
        [Byte[]]$iv = New-Object Byte[] $liv
        # reading iv-block content from license file
        $fileStreamReader.Seek(4, [System.IO.SeekOrigin]::Begin) | Out-Null
        $fileStreamReader.Read($iv, 0, $liv) | Out-Null
        $crypto.IV = $iv
        $decryptLicenseDataStatus = $true
    }
    catch {
        Write-Output "ERROR - (Master-BoT) - $($_)"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
        exit
    }
}
else {
    exit
}

# converting data into variable
if ($decryptLicenseDataStatus) {
    try {
        # decryping crpto message
        $transform = $crypto.CreateDecryptor()
        # copy message to memory
        $memoryStream = New-Object System.IO.MemoryStream
        $cryptoStream = New-Object System.Security.Cryptography.CryptoStream($memoryStream, $transform, [System.Security.Cryptography.CryptoStreamMode]::Write)
        $fileStreamReader.CopyTo($cryptoStream)
        # flash crypto memory block
        $cryptoStream.FlushFinalBlock()
        # close crypto memory stream
        $cryptoStream.Close()
        # close license file
        $fileStreamReader.Close()
        # copy memory data to variable
        $decryptedData = $memoryStream.ToArray()
        $decryptedString = [System.Text.Encoding]::UTF8.GetString($decryptedData)
        # close memory block
        $memoryStream.Close()
        $decryptVariableStatus = $true
    }
    catch {
        Write-Output "ERROR - (Master-BoT) - $($_)"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
        exit
    }
}
else {
    exit
}

# checking if the license file is valid or not
if ($decryptVariableStatus) {
    try {
        # converting decrypt license data inot json file
        $licenseData = $decryptedString | ConvertFrom-Json
        # checking if the demand id is same or not
        if ((([string]$licenseData.DemandID).ToUpper()) -eq "ENHC0012431") {
            # checking if the account name is same or not
            if ((([string]$licenseData.AccountName).ToUpper()) -eq "FDT") {
                # define start date
                $startDate = [datetime]::ParseExact($licenseData.StartDate, "dd-MM-yyyy", $null)
                # define expiry date
                $expiryDate = [datetime]::ParseExact($licenseData.ExpiryDate, "dd-MM-yyyy", $null)
                # define current date
                $currentDate = [datetime](Get-Date).ToString([System.Globalization.CultureInfo]::GetCultureInfo("en-US"))
                # compare expiry and current date
                if ($expiryDate -le $currentDate) {
                    Write-Output "ERROR - (Master-BoT) - Licensed Expired At $($expiryDate.ToString('dd MMMM yyyy'))"
                    & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - License Expired At $($expiryDate.ToString('dd MMMM yyyy'))"
                    # cheking all the mail-parameter
                    if (($configFile.SMTPServer -ne "") -and ($configFile.SMTPPort -ne "") -and ($configFile.LicenseExpiryToMail -ne "") -and ($configFile.LicenseExpiryFromMail -ne "")) {
                        # sending license expiry mail
                        try {
                            $licenseSubjectMail = "License Expired | Automation ID: $(([string]$licenseData.DemandID).ToUpper())"
                            $licenseMailBody = "Hi All,`r`nThe Automation Demand: $(([string]$licenseData.DemandID).ToUpper()) License Has Been Expired At $($expiryDate.ToString('dd MMMM yyyy')).`r`nPlease Reach Out To ciscreatesupport.in@capgemini.com For License Renewal.`r`n***** This Is System Generated E-Mail, Please Do Not Reply *****"
                            Send-MailMessage -SmtpServer $($configFile.SMTPServer) -Port $($configFile.SMTPPort) -From $($configFile.LicenseExpiryFromMail) -To $($configFile.LicenseExpiryToMail) -Subject $licenseSubjectMail -Body $licenseMailBody
                            & $LogEntry -LogFileName $logFileName -LogMessage "SUCCESS - (Master-BoT) - E-Mail Notification For License Expiry Has Been Sent To: $($configFile.LicenseExpiryFromMail)"
                            
                        }
                        catch {
                            Write-Output "ERROR - (Master-BoT) - $($_)"
                            & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
                            exit
                        }
                    }
                    else {
                        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - E-Mail Parameters Is Not Present"
                        exit
                    }
                    exit
                }
                else {
                    & $LogEntry -LogFileName $logFileName -LogMessage "SUCCESS - (Master-BoT) - License Start From: $($startDate.ToString('dd MMMM yyyy')) Valid Untill $($expiryDate.ToString('dd MMMM yyyy'))"
                    & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "LicenseCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAS" -subexec_status "LVS" -bot_log ($CurrentTime + "Success") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
                }
            }
            else {
                Write-Output "ERROR - (Master-BoT) - Account Name Is Mismatched"
                & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - Account Name Is Mismatched"
                exit
            }
        }
        else {
            Write-Output "ERROR - (Master-BoT) - Demand ID Is Mismathced"
            & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - Demand ID Is Mismatched"
            exit
        }
    }
    catch {
        Write-Output "ERROR - (Master-BoT) - $($_)"
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
        & $EnEBot -customer_short_name $enres.customer_short_name -ras_id $enres.ras_id -bot_id $enres.bot_id -solution $enres.solution -bot_name "MasterCheck" -region $enres.region -itsm_customer $enres.itsm_customer -itsm_record $enres.itsm_record -target_endpoint $localHost -source_system $enres.source_system -execution_end_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -execution_status "BAF" -subexec_status "LVF" -bot_log ($CurrentTime + "Error connecting masterbot") -bot_path $masterbotfile -bot_hash $enres.bot_hash -bot_version $enres.bot_version -execution_start_time (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -ene_folder_path "C:\Automation\EnE" -run_id $run_id
        exit
    }
}
else {
    exit
}
##################################################

################ welcome banner ##################
try {
    Write-Output ("`r`n" + "#" * 50)
    Write-Output "- Demand ID:      ENHC0012431"
    Write-Output "- Use Case Name:  Ms_Defender Email Blocking And Soft Deletion"
    Write-Output "- License Start:  $($startDate.ToString('dd-MMM-yyyy'))"
    Write-Output "- License Expiry: $($expiryDate.ToString('dd-MMM-yyyy'))"
    Write-Output "- Days Remain:    $(($expiryDate - $currentDate).Days)"
    Write-Output "- Executed By:    $(($env:USERNAME).ToUpper())"
    Write-Output "- Executed At:    $(($env:COMPUTERNAME).ToUpper())"
    Write-Output "- System Date:    $((Get-Date).ToString('dd-MMM-yyyy'))"
    Write-Output "- System Time:    $((Get-Date).ToString('hh:mm:ss tt'))"
    Write-Output ("#" * 50 + "`r`n")
}
catch {
    Write-Output "ERROR - (Master-BoT) - $($_)"
}
##################################################

##########################################################################################
############################## DO NOT CHANGE ANYTHING ABOVE ##############################
##########################################################################################


try {
    Write-Host "Calling Microbot............"
    & $LogEntry -LogFileName $logFileName -LogMessage "Calling Microbot................"
    $outputPath = & $microbot -inputfilepath $inputfilepath -LogEntry $LogEntry -LogFileName $logFileName -outputFolderPath $outputFolderPath -VerificationDelay $($configFile.VerificationDelay) -EnEBot $EnEBot
    Write-Host "in masterbot output path = $($outputPath)"
}
catch {
    Write-Host "ERROR - (MaterBot) - $($_)"
}



##########################################################################################
############################## DO NOT CHANGE ANYTHING BELOW ##############################
##########################################################################################

################# sending email ##################
try {
    # if email is required
    if (([string]$configFile.EmailRequired).ToLower() -eq "yes") {
        Write-Host "Attachment : $($outputPath)"
        # checking if all the parameter is present
        if (([string]$configFile.SMTPServer -ne "") -and ([string]$configFile.SMTPPort -ne "") -and ([string]$configFile.ToMail -ne "") -and ([string]$configFile.FromMail -ne "") -and ([string]$configFile.SubjectMail -ne "") -and ([string]$configFile.BodyMail -ne "")) {
            # fetching smtp server reachability
            $smtpResult = Test-NetConnection -ComputerName $configFile.SMTPServer -Port $configFile.SMTPPort
            # if TCPTestSuccessded
            if ($smtpResult.TcpTestSucceeded) {
                # if attachment is required
                Send-MailMessage -SmtpServer $($configFile.SMTPServer) -Port $($configFile.SMTPPort) -From $($configFile.FromMail) -To $($configFile.ToMail) -Subject $($configFile.SubjectMail) -Body $($configFile.BodyMail) -Attachments $outputPath
                & $LogEntry -LogFileName $logFileName -LogMessage "SUCCESS - (Master-BoT) - EMail Sent To $(($configFile.ToMail).ToLower()) With Attachment"
                
            }
            else {
                & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - SMTP Server: $($configFile.SMTPServer) Is Not Reachable"
            }
        }
        else {
            & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - SMTP Not Configured Properly"
        }
    }
    elseif (([string]$configFile.EmailRequired).ToLower() -eq "no") {
        & $LogEntry -LogFileName $logFileName -LogMessage "INFO - (Master-BoT) - EMail Is Not Required"
    }
    else {
        & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - Required Of EMail Is Configured"
    }
}
catch {
    & $LogEntry -LogFileName $logFileName -LogMessage "ERROR - (Master-BoT) - $($_)"
}
##################################################